# Animal-Website
This is my animal website. It contains 3 html pages with information, videos, and lists of data about the Bengal Tiger
